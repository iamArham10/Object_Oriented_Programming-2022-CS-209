﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shooting_Game
{
    class spaceship
    {
        public int position_x;
        public int position_y;
        public char[,] structure = new char[3, 2];
        public int health = 100;
        
    }
}
