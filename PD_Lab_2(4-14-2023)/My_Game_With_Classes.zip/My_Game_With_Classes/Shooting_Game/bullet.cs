﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shooting_Game
{
    class bullet
    {
        public int position_x;
        public int position_y;
        public bool Is_Active;
    }
}
